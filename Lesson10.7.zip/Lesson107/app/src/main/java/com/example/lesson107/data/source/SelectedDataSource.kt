package com.example.lesson107.data.source

enum class SelectedDataSource {
    LOCAL,
    REMOTE
}